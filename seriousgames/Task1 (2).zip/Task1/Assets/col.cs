﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class col : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D col)
    {
        GameObject.Destroy(this.gameObject);
        Text.Destroy(this);
        
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
