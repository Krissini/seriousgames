﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class deployCoins : MonoBehaviour
{
    public Text coin_eins;
    public Text coin_zwei;
    public Text coin_drei;
    public Text coin_vier;
    public GameObject coinPrefab;

    void SpawnCoin()
    {
        GameObject a = Instantiate(coinPrefab) as GameObject;
        GameObject b = Instantiate(coinPrefab) as GameObject;
        GameObject c = Instantiate(coinPrefab) as GameObject;
        GameObject d = Instantiate(coinPrefab) as GameObject;
        a.transform.position = new Vector2(coin_eins.transform.position.x - 1, coin_eins.transform.position.y + 1);
        b.transform.position = new Vector2(coin_zwei.transform.position.x - 1, coin_zwei.transform.position.y + 1);
        c.transform.position = new Vector2(coin_drei.transform.position.x - 1, coin_drei.transform.position.y + 1);
        d.transform.position = new Vector2(coin_vier.transform.position.x - 1, coin_vier.transform.position.y + 1);
    }
    // Start is called before the first frame update
    void Start()
    {
        SpawnCoin();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
