﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class manageText : MonoBehaviour
{
    public Text coin_eins;
    public Text coin_zwei;
    public Text coin_drei;
    public Text coin_vier;
    public Text aufgabe;
    // Start is called before the first frame update
    void Start()
    {
        coin_eins.text = "12";
        coin_zwei.text = "12";
        coin_drei.text = "12";
        coin_vier.text = "12";
        coin_eins.transform.position = new Vector2(Random.Range(-10, 10), Random.Range(-10, 10));
        coin_zwei.transform.position = new Vector2(Random.Range(-10, 10), Random.Range(-10, 10));
        coin_drei.transform.position = new Vector2(Random.Range(-10, 10), Random.Range(-10, 10));
        coin_vier.transform.position = new Vector2(Random.Range(-10, 10), Random.Range(-10, 10));




        //aufgabe.transform.position = canvas.transform.position;


    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
